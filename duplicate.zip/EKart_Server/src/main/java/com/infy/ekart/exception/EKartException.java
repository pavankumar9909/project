package com.infy.ekart.exception;

public class EKartException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartException(String message) {
		super(message);
	}

}
